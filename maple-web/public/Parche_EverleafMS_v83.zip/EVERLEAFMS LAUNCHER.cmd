@echo off
title EverleafMS Launcher
echo Iniciando EverleafMS v83...
taskkill /f /im EverleafMS.exe >nul 2>&1
taskkill /f /im MapleStory.exe >nul 2>&1
start "" "EverleafMS.exe"
exit
